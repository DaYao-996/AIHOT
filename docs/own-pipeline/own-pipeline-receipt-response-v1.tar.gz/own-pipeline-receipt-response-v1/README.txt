Targeted archive for the receipt response binding only.
Parent is 8076fba. The v10 review object f60e4f59 is not rewritten.
Apply PATCH onto 8076fba. This is not a full pin replay and it does not replace the evidence-byte pack.
Response schema is own-model-output-v1.
The bound object is output.{materialStatus,factStatus,valueStatus,releaseStatus,reasons}.
Canonical form is stableJson of that object. outputSha256 is sha256 of that string, computed from the parsed response.
Unknown shapes are rejected. A caller-supplied hash string is not the binding.
